"""
Minimal FastAPI app exposing the scoring pipeline.
This is intentionally bare right now - no auth, no database, no login flow.
Those come later, once the scoring logic itself is proven and confirmed.
"""

from fastapi import FastAPI
from pydantic import BaseModel

from app.pipeline import run_pipeline

app = FastAPI(title="Qriosity Quest Scoring Pipeline")


class SubmissionRequest(BaseModel):
    mcq_answers: dict[str, str]   # {"1": "b", "4": "b", ...}
    open_answers: dict[str, str]  # {"2": "...", "3": "...", ...}


@app.post("/score")
def score_submission(submission: SubmissionRequest):
    return run_pipeline(submission.mcq_answers, submission.open_answers)


@app.get("/health")
def health_check():
    return {"status": "ok"}
