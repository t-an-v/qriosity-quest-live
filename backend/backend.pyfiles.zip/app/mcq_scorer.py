"""
Deterministic scorer for MCQ questions.
No LLM calls here - pure lookup against the rubric's option_score_map.
Fast, free, and fully predictable - this is our reliability baseline.
"""

import json
from pathlib import Path

RUBRIC_PATH = Path(__file__).parent.parent / "data" / "rubric.json"


def load_rubric() -> dict:
    with open(RUBRIC_PATH, "r") as f:
        return json.load(f)


def score_mcq_answer(question_id: str, selected_option: str, rubric: dict) -> dict:
    """
    Scores a single MCQ answer using the rubric's option_score_map.

    Returns a dict with the score, trait, and a flag if the mapping
    for this option hasn't been confirmed yet (still None in rubric.json).
    """
    question = rubric["questions"].get(str(question_id))
    if question is None:
        raise ValueError(f"Unknown question id: {question_id}")

    if question["type"] != "mcq":
        raise ValueError(f"Question {question_id} is not an MCQ question")

    option_map = question.get("option_score_map", {})
    score = option_map.get(selected_option.lower())

    return {
        "question_id": question_id,
        "trait": question["trait"],
        "selected_option": selected_option,
        "score": score,
        "needs_confirmation": score is None,
    }


def score_all_mcq(mcq_answers: dict, rubric: dict) -> list[dict]:
    """
    mcq_answers: {"1": "b", "4": "b", "7": "c", ...}
    Returns a list of per-question score results.
    """
    results = []
    for question_id, selected_option in mcq_answers.items():
        results.append(score_mcq_answer(question_id, selected_option, rubric))
    return results


if __name__ == "__main__":
    # Quick manual test
    rubric = load_rubric()
    sample_answers = {"1": "b", "4": "b", "11": "b"}
    for result in score_all_mcq(sample_answers, rubric):
        print(result)
