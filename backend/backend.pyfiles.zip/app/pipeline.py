"""
Orchestrates the full scoring pipeline for one student's submission:

  1. Score MCQ answers with rules (fast, free, deterministic)
  2. Score open-ended answers with Gemini (structured JSON prompting)
  3. Validate every Gemini quote against the raw answer (hallucination guard)
  4. Aggregate per-trait totals
  5. Return a single structured result ready for report generation

This is the file that ties mcq_scorer, open_ended_scorer, and validator
together - nothing else in the codebase should need to know about all
three at once.
"""

from collections import defaultdict

from app.mcq_scorer import load_rubric, score_all_mcq
from app.open_ended_scorer import score_all_open_ended
from app.validator import validate_all


def run_pipeline(mcq_answers: dict, open_answers: dict) -> dict:
    """
    mcq_answers: {"1": "b", "4": "b", ...}
    open_answers: {"2": "student's written response", "3": "...", ...}
    """
    rubric = load_rubric()

    mcq_results = score_all_mcq(mcq_answers, rubric)
    open_results_raw = score_all_open_ended(open_answers, rubric)
    open_results = validate_all(open_results_raw)

    unresolved = [r for r in mcq_results if r["needs_confirmation"]]
    unvalidated = [r for r in open_results if not r["validated"]]

    trait_totals = compute_trait_totals(mcq_results, open_results, rubric)

    return {
        "mcq_results": mcq_results,
        "open_ended_results": open_results,
        "trait_totals": trait_totals,
        "warnings": {
            "mcq_needs_confirmation": [r["question_id"] for r in unresolved],
            "open_ended_failed_validation": [r["question_id"] for r in unvalidated],
        },
    }


def compute_trait_totals(mcq_results: list[dict], open_results: list[dict], rubric: dict) -> dict:
    """
    Sums scores per trait, skipping questions marked as not counting
    toward trait totals (currently: the two 'open_ended' category questions).
    """
    totals = defaultdict(int)
    max_possible = defaultdict(int)

    all_results = mcq_results + open_results

    for result in all_results:
        question = rubric["questions"][str(result["question_id"])]
        if not question.get("counts_toward_trait_total", True):
            continue
        if result.get("score") is None:
            continue  # unresolved MCQ mapping - don't silently count as 0

        trait = result["trait"]
        totals[trait] += result["score"]
        max_possible[trait] += 4

    return {
        trait: {
            "score": totals[trait],
            "max_possible": max_possible[trait],
            "percentage": round(100 * totals[trait] / max_possible[trait], 1) if max_possible[trait] else None,
        }
        for trait in totals
    }
