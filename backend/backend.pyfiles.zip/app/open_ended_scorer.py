"""
Scores open-ended (subjective) answers using Gemini with structured JSON prompting.
Same pattern as the privacy policy grader: strict JSON output, one call per answer,
no free-form text response that we'd have to parse loosely.

Uses the new `google.genai` SDK (the old `google.generativeai` package is
deprecated as of 2026 and no longer receives updates/fixes).
"""

import json
import os
import time
from pathlib import Path

from google import genai
from google.genai import types
from dotenv import load_dotenv

load_dotenv()  # reads GEMINI_API_KEY from a local .env file - never commit that file

RUBRIC_PATH = Path(__file__).parent.parent / "data" / "rubric.json"

client = genai.Client(api_key=os.environ.get("GEMINI_API_KEY"))
MODEL_NAME = "gemini-3.5-flash-lite"  # free-tier friendly: higher RPM than standard Flash, good for iterative testing
# Alternative if you want slightly stronger reasoning and can live with lower RPM: "gemini-3.6-flash"


def load_rubric() -> dict:
    with open(RUBRIC_PATH, "r") as f:
        return json.load(f)


def build_prompt(question_prompt: str, criteria: dict, student_answer: str) -> str:
    """
    Builds a structured prompt that forces Gemini to return ONLY JSON.
    Keeping the criteria in the prompt (not just implied) is what makes
    scoring consistent across different students' answers.
    """
    criteria_text = "\n".join(f"{level}: {desc}" for level, desc in criteria.items())

    return f"""You are scoring a student's answer to a reflective assessment question.
Score strictly against the criteria below - do not be lenient, do not invent
strengths the answer doesn't show.

QUESTION: {question_prompt}

SCORING CRITERIA (1-4 scale):
{criteria_text}

STUDENT'S ANSWER:
\"\"\"{student_answer}\"\"\"

Respond with ONLY valid JSON, no markdown formatting, no preamble, in this exact shape:
{{
  "score": <integer 1-4>,
  "quoted_evidence": "<a short exact phrase copied directly from the student's answer that justifies the score - must be verbatim from their answer, not paraphrased>",
  "feedback": "<one warm, encouraging sentence explaining the score, written for the student to read>"
}}"""


def call_with_retry(prompt: str, max_retries: int = 3):
    """
    Handles the free tier's rate limit (429 errors) gracefully instead of
    crashing the whole batch. Waits longer each retry (backoff), since
    hammering the API immediately after a 429 just makes it worse.
    """
    for attempt in range(max_retries):
        try:
            return client.models.generate_content(
                model=MODEL_NAME,
                contents=prompt,
                config=types.GenerateContentConfig(
                    response_mime_type="application/json",
                ),
            )
        except Exception as e:
            if "429" in str(e) or "quota" in str(e).lower() or "RESOURCE_EXHAUSTED" in str(e):
                wait_time = (attempt + 1) * 15  # 15s, 30s, 45s
                print(f"Rate limit hit, waiting {wait_time}s before retry {attempt + 1}/{max_retries}...")
                time.sleep(wait_time)
            else:
                raise
    raise RuntimeError("Gemini API rate limit exceeded after retries - try again in a minute, or check your daily quota hasn't been hit.")


def score_open_ended_answer(question_id: str, student_answer: str, rubric: dict) -> dict:
    question = rubric["questions"].get(str(question_id))
    if question is None:
        raise ValueError(f"Unknown question id: {question_id}")

    prompt = build_prompt(question["prompt"], question["criteria"], student_answer)

    response = call_with_retry(prompt)

    try:
        parsed = json.loads(response.text.strip())
    except json.JSONDecodeError:
        # TODO: add retry-with-stricter-prompt logic here before this goes live
        raise ValueError(f"Gemini did not return valid JSON for question {question_id}: {response.text}")

    return {
        "question_id": question_id,
        "trait": question["trait"],
        "score": parsed["score"],
        "quoted_evidence": parsed["quoted_evidence"],
        "feedback": parsed["feedback"],
        "raw_student_answer": student_answer,  # kept for the validation layer
    }


def score_all_open_ended(open_answers: dict, rubric: dict) -> list[dict]:
    """
    open_answers: {"2": "I would ask the plant if...", "3": "...", ...}
    """
    return [
        score_open_ended_answer(qid, answer, rubric)
        for qid, answer in open_answers.items()
    ]